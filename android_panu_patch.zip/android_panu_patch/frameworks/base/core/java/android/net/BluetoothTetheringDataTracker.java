/*
 * Copyright (C) 2010 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package android.net;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.DhcpInfo;
import android.net.NetworkInfo;
import android.net.NetworkInfo.DetailedState;
import android.net.NetworkStateTracker;
import android.net.NetworkUtils;
import android.server.BluetoothPanService;
import android.bluetooth.IBluetoothPan;
import android.bluetooth.BluetoothDevice;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Track the state of bluetooth data connectivity. This is done by
 * receiving broadcast intents from the Phone process whenever
 * the state of data connectivity changes.
 *
 */
public class BluetoothTetheringDataTracker extends NetworkStateTracker {
    private static final String NETWORKTYPE = "BLUETOOTH_TETHER";
    private static final String TAG = "BluetoothTethering";

    private static String mIface;

    private Handler mCsHandler;
    public static BluetoothTetheringDataTracker sInstance;
    private IBluetoothPan mService;

    public BluetoothTetheringDataTracker(Context context, Handler target) {
        super(context, target, ConnectivityManager.TYPE_BLUETOOTH, 0, NETWORKTYPE, "");
        mCsHandler = target;
        mNetworkInfo.setIsAvailable(false);

        mDnsPropNames = new String[] {
            "dhcp.bnep0.dns1",
            "dhcp.bnep0.dns2",
            "dhcp.bnep0.dns3",
            "dhcp.bnep0.dns4"
        };

        sInstance = this;
    }

    public static synchronized BluetoothTetheringDataTracker getInstance() {

	if(sInstance == null)
	{
		Log.e(TAG,"BluetoothTetheringDataTracker instance is null");
	}
        return sInstance;
    }

    public void startMonitoring() {
        IBinder b = ServiceManager.getService(BluetoothPanService.BLUETOOTH_PAN_SERVICE);
        if (b != null) {
            mService = IBluetoothPan.Stub.asInterface(b);
        } else {
            Log.e(TAG, "Bluetooth PAN service not available!");
            mService = null;
        }

    }


    public boolean teardown() {
        Set<BluetoothDevice> mDevices;
        if (mService != null) {
            try {
                mDevices = Collections.unmodifiableSet(new HashSet<BluetoothDevice>(Arrays.asList(mService.getConnectedPanDevices())));
                for (BluetoothDevice device: mDevices) {
                    mService.disconnectPanDevice(device);
                }
            } catch (RemoteException e) {
                Log.e(TAG, "", e);
                return false;
            }

        }
        return true;
    }


    public boolean reconnect() {
        return true;
    }


    public boolean setRadio(boolean turnOn) {
        return true;
    }


    public synchronized boolean isAvailable() {
        return mNetworkInfo.isAvailable();
    }

    public int startUsingNetworkFeature(String feature, int callingPid, int callingUid) {
        return -1;
    }

    public int stopUsingNetworkFeature(String feature, int callingPid, int callingUid) {
        return -1;
    }

    public String getTcpBufferSizesPropName() {
        return "net.tcp.buffersize.wifi";
    }

    @Override
    public boolean requestRouteToHost(int hostAddress) {
        Log.e(TAG, "Requested host route to " + Integer.toHexString(hostAddress));

        if (mInterfaceName != null && hostAddress != -1) {
            return NetworkUtils.addHostRoute(mInterfaceName, hostAddress) == 0;
        } else {
            return false;
        }
    }


    public synchronized void startReverseTether(String iface) {
        mIface = iface;
        Log.e(TAG, "in startReverseTether");
        Thread dhcpThread = new Thread(new Runnable() {
            public void run() {
                //TODO(): Add callbacks for failure and success case.
                //Currently this thread runs independently.
                DhcpInfo dhcpInfo = new DhcpInfo();
                if (!NetworkUtils.runDhcp(mIface, dhcpInfo)) {
                    Log.e(TAG, "DHCP request error:" + NetworkUtils.getDhcpError());
                    return;
                }


                mInterfaceName = mIface;
                mDefaultGatewayAddr = dhcpInfo.gateway;

                mNetworkInfo.setIsAvailable(true);
                mNetworkInfo.setDetailedState(DetailedState.CONNECTED, null, null);

                Message msg = mCsHandler.obtainMessage(EVENT_CONFIGURATION_CHANGED, mNetworkInfo);
                msg.sendToTarget();

                msg = mCsHandler.obtainMessage(EVENT_STATE_CHANGED, mNetworkInfo);
                msg.sendToTarget();
            }
        });
        dhcpThread.start();
    }

    public synchronized void stopReverseTether(String iface) {
        Log.e(TAG, "in stopReverseTether");
        NetworkUtils.stopDhcp(iface);

        mNetworkInfo.setIsAvailable(false);
        mNetworkInfo.setDetailedState(DetailedState.DISCONNECTED, null, null);

        Message msg = mCsHandler.obtainMessage(EVENT_CONFIGURATION_CHANGED, mNetworkInfo);
        msg.sendToTarget();

        msg = mCsHandler.obtainMessage(EVENT_STATE_CHANGED, mNetworkInfo);
        msg.sendToTarget();
    }

}
