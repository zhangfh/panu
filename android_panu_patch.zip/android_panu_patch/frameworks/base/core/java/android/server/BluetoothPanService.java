/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * TODO: Move this to services.jar
 * and make the contructor package private again.
 * @hide
 */

package android.server;


import android.net.ConnectivityManager;
import android.net.NetworkStateTracker;
import android.net.NetworkUtils;
import android.net.NetworkInfo;
import android.net.NetworkInfo.DetailedState;
import android.net.DhcpInfo;
import android.net.BluetoothTetheringDataTracker;
import android.bluetooth.BluetoothPan;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothUuid;
import android.bluetooth.IBluetoothPan;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Message;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.util.Log;
import android.os.Looper;

import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.ArrayList;


public class BluetoothPanService extends IBluetoothPan.Stub {
    private static final String TAG = "BluetoothPanService";
    private static final boolean DBG = true;

    public static final String BLUETOOTH_PAN_SERVICE = "bluetooth_pan";
    private static final String NETWORKTYPE = "BLUETOOTH_TETHER";

    private static final String BLUETOOTH_ADMIN_PERM = android.Manifest.permission.BLUETOOTH_ADMIN;
    private static final String BLUETOOTH_PERM = android.Manifest.permission.BLUETOOTH;

    private static final String BLUETOOTH_ENABLED = "bluetooth_enabled";

    private static final String PROPERTY_STATE = "State";

    private static final String BLUETOOTH_IFACE_ADDR_START= "192.168.44.1";
    private static final int BLUETOOTH_MAX_PAN_CONNECTIONS = 8;
    private static final int BLUETOOTH_PREFIX_LENGTH = 24;

    private final HashMap<BluetoothDevice, BluetoothPanDevice> mPanDevices;
    private ArrayList<String> mBluetoothIfaceAddresses;
    private final Context mContext;
    private final BluetoothService mBluetoothService;
    private final BluetoothAdapter mAdapter;
    private NetworkInfo mNetworkInfo;
    private int mMaxPanDevices;

    private static int mCount;
    private boolean mTetheringOn;

    private static String mIface;
    private Handler mCsHandler;

    private class BluetoothPanDevice {
        private int mState;
        private String mIfaceAddr;
        private String mIface;
        private int mLocalRole; // Which local role is this PAN device bound to

        BluetoothPanDevice(int state, String ifaceAddr, String iface, int localRole) {
            mState = state;
            mIfaceAddr = ifaceAddr;
            mIface = iface;
            mLocalRole = localRole;

            Log.e(TAG, "BluetoothPanDevice()");
        }
    }

    public BluetoothPanService(Context context, BluetoothService bluetoothService) {
        mContext = context;
        mTetheringOn = false;
        mMaxPanDevices = BLUETOOTH_MAX_PAN_CONNECTIONS;

        mPanDevices = new HashMap<BluetoothDevice, BluetoothPanDevice>();
        mBluetoothIfaceAddresses = new ArrayList<String>();
        mNetworkInfo = new NetworkInfo(ConnectivityManager.TYPE_BLUETOOTH, 0, NETWORKTYPE, "");
        mNetworkInfo.setIsAvailable(false);

        Log.e(TAG, "BluetoothPanService()");

        mBluetoothService = bluetoothService;
        if (mBluetoothService == null) {
            throw new RuntimeException("Platform does not support Bluetooth");
        }

        if (!initNative()) {
            throw new RuntimeException("Could not init BluetoothPanService");
        }

        mAdapter = BluetoothAdapter.getDefaultAdapter();
        mBluetoothService.setPanService(this);

        IntentFilter mIntentFilter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        mIntentFilter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        mContext.registerReceiver(mReceiver, mIntentFilter);
    }

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                BluetoothDevice device =
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
                    int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE,
                            BluetoothAdapter.ERROR);
                    if(BluetoothAdapter.STATE_TURNING_OFF == state) {
                        onBluetoothDisable();
                    }
                }
            }
    };

    private synchronized void onBluetoothDisable() {
        synchronized (this) {
            for (BluetoothDevice device: mPanDevices.keySet()) {
                if (getPanDeviceConnectionState(device) == BluetoothPan.STATE_CONNECTED) {
                    String objectPath = mBluetoothService.getObjectPathFromAddress(device.getAddress());
                    Log.e(TAG, "disconnect PAN(" + objectPath + ")");

                    BluetoothPanDevice panDevice = mPanDevices.get(device);

                    if (panDevice == null) {
                        Log.e(TAG, "No record for this Pan device:" + device);
                        continue;
                    }

                    handlePanDeviceStateChange(device, panDevice.mIface, BluetoothPan.STATE_DISCONNECTING,
                            panDevice.mLocalRole);
                    if (panDevice.mLocalRole == BluetoothPan.LOCAL_NAP_ROLE) {
                        if (!disconnectPanServerDeviceNative(objectPath, device.getAddress(),
                                    panDevice.mIface)) {
                            handlePanDeviceStateChange(device, panDevice.mIface, BluetoothPan.STATE_DISCONNECTING, panDevice.mLocalRole);
                            continue;
                        }
                    } else {
                        //we support panu only now, so only one device will be disconnected in this case 
                        if (!disconnectPanDeviceNative(objectPath)) {
                            handlePanDeviceStateChange(device, panDevice.mIface, BluetoothPan.STATE_DISCONNECTING, panDevice.mLocalRole);
                            continue;
                        }
                    }
                }
            }
        }
    }

    public boolean isTetheringOn() {
        synchronized (this) {
            return mTetheringOn;
        }
    }

    boolean allowIncomingTethering() {
        synchronized (this) {
            if (isTetheringOn() && getConnectedPanDevices().length < mMaxPanDevices)
                return true;
            return false;
        }
    }


    public void setBluetoothTethering(boolean value) {
        synchronized (this) {
            if (!value) {
                disconnectPanServerDevices();
            }

            String adapterPath = mBluetoothService.getAdapterPathNative();
            if(adapterPath != null) {
                setBluetoothTetheringNative(value, BluetoothPan.NAP_ROLE, BluetoothPan.NAP_BRIDGE, adapterPath);
            }
            mTetheringOn = value;
        }
    }

    public int getPanDeviceConnectionState(BluetoothDevice device) {

        synchronized (this) {
            BluetoothPanDevice panDevice = mPanDevices.get(device);
            if (panDevice == null) {
                return BluetoothPan.STATE_DISCONNECTED;
            }
            return panDevice.mState;
        }
    }

    public int getPanDeviceRole(BluetoothDevice device) {

        synchronized (this) {
            BluetoothPanDevice panDevice = mPanDevices.get(device);
            if (panDevice == null) {
                return 0;
            }
            return panDevice.mLocalRole;
        }
    }

    public boolean connectPanDevice(BluetoothDevice device) {

        synchronized (this) {
            String objectPath = mBluetoothService.getObjectPathFromAddress(device.getAddress());
            if (DBG) Log.e(TAG, "connect PAN(" + objectPath + ")");
            if (getPanDeviceConnectionState(device) != BluetoothPan.STATE_DISCONNECTED) {
                Log.e(TAG, device + " already connected to PAN");
                return true;//??problem??
            }

            int connectedCount = 0;
            for (BluetoothDevice panDevice: mPanDevices.keySet()) {
                if (getPanDeviceConnectionState(panDevice) == BluetoothPan.STATE_CONNECTED) {
                    connectedCount ++;
                }
            }
            if (connectedCount > 8) {
                Log.e(TAG, device + " could not connect to PAN, because 8 other devices are"
                        + "already connected");
                return false;
            }

            // Send interface as null as it is not known
            handlePanDeviceStateChange(device, null, BluetoothPan.STATE_CONNECTING,
                    BluetoothPan.LOCAL_PANU_ROLE);
            if (connectPanDeviceNative(objectPath, "nap")) {
                Log.e(TAG, "connecting to PAN");

                return true;
            } else {
                handlePanDeviceStateChange(device, null, BluetoothPan.STATE_DISCONNECTED,
                        BluetoothPan.LOCAL_PANU_ROLE);
                Log.e(TAG, "could not connect to PAN");
                return false;
            }
        }
    }

    public boolean disconnectPanServerDevices() {
        Log.e(TAG, "disconnect all PAN devices");

        synchronized (this) {
            for (BluetoothDevice device: mPanDevices.keySet()) {
                BluetoothPanDevice panDevice = mPanDevices.get(device);
                int state = panDevice.mState;
                if (state == BluetoothPan.STATE_CONNECTED &&
                        panDevice.mLocalRole == BluetoothPan.LOCAL_NAP_ROLE) {
                    String objectPath = mBluetoothService.getObjectPathFromAddress(device.getAddress());

                    handlePanDeviceStateChange(device, panDevice.mIface,
                            BluetoothPan.STATE_DISCONNECTING, panDevice.mLocalRole);

                    if (!disconnectPanServerDeviceNative(objectPath,
                                device.getAddress(),
                                panDevice.mIface)) {
                        Log.e(TAG, "could not disconnect Pan Server Device "+device.getAddress());

                        // Restore prev state
                        handlePanDeviceStateChange(device, panDevice.mIface, state,
                                panDevice.mLocalRole);

                        return false;
                    }
                }
            }
            return true;
        }
    }

    public BluetoothDevice[] getConnectedPanDevices() {

        synchronized (this) {
            Set<BluetoothDevice> devices=new HashSet<BluetoothDevice>(); 
            for (BluetoothDevice device: mPanDevices.keySet()) {
                if (getPanDeviceConnectionState(device) == BluetoothPan.STATE_CONNECTED) {
                    devices.add(device);
                }
            }
            return devices.toArray(new BluetoothDevice[devices.size()]);
        }
    }

    public boolean disconnectPanDevice(BluetoothDevice device) {

        synchronized (this) {
            String objectPath = mBluetoothService.getObjectPathFromAddress(device.getAddress());
            Log.e(TAG, "disconnect PAN(" + objectPath + ")");

            int state = getPanDeviceConnectionState(device);
            if (state != BluetoothPan.STATE_CONNECTED) {
                Log.e(TAG, device + " already disconnected from PAN");
                return false;
            }

            BluetoothPanDevice panDevice = mPanDevices.get(device);

            if (panDevice == null) {
                Log.e(TAG, "No record for this Pan device:" + device);
                return false;
            }

            handlePanDeviceStateChange(device, panDevice.mIface, BluetoothPan.STATE_DISCONNECTING,
                    panDevice.mLocalRole);
            if (panDevice.mLocalRole == BluetoothPan.LOCAL_NAP_ROLE) {
                if (!disconnectPanServerDeviceNative(objectPath, device.getAddress(),
                            panDevice.mIface)) {
                    // Restore prev state, this shouldn't happen
                    handlePanDeviceStateChange(device, panDevice.mIface, state, panDevice.mLocalRole);
                    return false;
                }
            } else {
                if (!disconnectPanDeviceNative(objectPath)) {
                    // Restore prev state, this shouldn't happen
                    handlePanDeviceStateChange(device, panDevice.mIface, state, panDevice.mLocalRole);
                    return false;
                }
            }
            return true;
        }
    }

    private void onPanDevicePropertyChanged(String deviceObjectPath, String[] propValues) {

        synchronized (this) {
            String name = propValues[0];
            String address = mBluetoothService.getAddressFromObjectPath(deviceObjectPath);


            Log.e(TAG, "onPanDevicePropertyChanged");
            if (address == null) {
                Log.e(TAG, "onPanDevicePropertyChanged: Address of the remote device in null");
                return;
            }
            if (DBG) {
                log("Pan Device property changed: " + address + "  property: "
                        + name + " value: "+ propValues[1]);
            }
            BluetoothDevice device = mAdapter.getRemoteDevice(address);
            if (name.equals("Connected")) {
                log("Connected");
                if (propValues[1].equals("false")) {
                    log("Connected false");
                    handlePanDeviceStateChange(device, null,
                            BluetoothPan.STATE_DISCONNECTED,
                            BluetoothPan.LOCAL_PANU_ROLE);
                }
            } else if (name.equals("Interface")) {
                String iface = propValues[1];
                log("interface");
                if (!iface.equals("")) {
                    log("interface true");
                    handlePanDeviceStateChange(device, iface,
                            BluetoothPan.STATE_CONNECTED,
                            BluetoothPan.LOCAL_PANU_ROLE);
                }
            }
        }
    }
    private void onPanDeviceConnectionResult(String path, int result) {
        log ("onPanDeviceConnectionResult " + path + " " + result);

        synchronized (this) {
            // Success case gets handled by Property Change signal
            if (result != BluetoothPan.PAN_OPERATION_SUCCESS) {
                String address = mBluetoothService.getAddressFromObjectPath(path);
                if (address == null) return;

                boolean connected = false;
                BluetoothDevice device = mAdapter.getRemoteDevice(address);
                int state = getPanDeviceConnectionState(device);
                if (state == BluetoothPan.STATE_CONNECTING) {
                    if (result == BluetoothPan.PAN_CONNECT_FAILED_ALREADY_CONNECTED) {
                        connected = true;
                    } else {
                        connected = false;
                    }
                } else if (state == BluetoothPan.STATE_DISCONNECTING) {
                    if (result == BluetoothPan.PAN_DISCONNECT_FAILED_NOT_CONNECTED) {
                        connected = false;
                    } else {
                        // There is no better way to handle this, this shouldn't happen
                        connected = true;
                    }
                } else {
                    Log.e(TAG, "Error onPanDeviceConnectionResult. State is: "
                            + state + " result: "+ result);
                }
                int newState = connected? BluetoothPan.STATE_CONNECTED :
                    BluetoothPan.STATE_DISCONNECTED;
                Log.e(TAG, "new state = " + newState);
                handlePanDeviceStateChange(device, null, newState,
                        BluetoothPan.LOCAL_PANU_ROLE);
            }
        }
    }
    private void onNetworkDeviceDisconnected(String address) {

        Log.e(TAG, "onNetworkDeviceDisconnected address:" + address);
        synchronized (this) {
            BluetoothDevice device = mAdapter.getRemoteDevice(address);
            handlePanDeviceStateChange(device, null, BluetoothPan.STATE_DISCONNECTED,
                    BluetoothPan.LOCAL_NAP_ROLE);
        }
    }
    private void onNetworkDeviceConnected(String address, String iface, int destUuid) {

        Log.e(TAG, "onNetworkDeviceDisconnected address:" + address + iface + destUuid);
        synchronized (this) {
            BluetoothDevice device = mAdapter.getRemoteDevice(address);
            handlePanDeviceStateChange(device, iface, BluetoothPan.STATE_CONNECTED,
                    BluetoothPan.LOCAL_NAP_ROLE);
        }
    }

    void handlePanDeviceStateChange(BluetoothDevice device, String iface, int state, int role) {

        synchronized (this) {
            int prevState;
            String ifaceAddr = null;
            BluetoothPanDevice panDevice = mPanDevices.get(device);

            Log.e(TAG, "in func handlePanDeviceStateChang" +" iface="+ iface + " state=" + state + " role=" + role);
            if (panDevice == null) {
                prevState = BluetoothPan.STATE_DISCONNECTED;
            } else {
                prevState = panDevice.mState;
                ifaceAddr = panDevice.mIfaceAddr;
            }
            if (prevState == state) return;

            if (role == BluetoothPan.LOCAL_NAP_ROLE) {
                if (state == BluetoothPan.STATE_CONNECTED) {
                    ifaceAddr = enableTethering(iface);
                    if (ifaceAddr == null) Log.e(TAG, "Error seting up tether interface");
                } else if (state == BluetoothPan.STATE_DISCONNECTED) {
                    if (ifaceAddr != null) {
                        mBluetoothIfaceAddresses.remove(ifaceAddr);
                        ifaceAddr = null;
                    }
                }
            } else {
                //reverse Tether
                if (state == BluetoothPan.STATE_CONNECTED) {
                    BluetoothTetheringDataTracker.getInstance().startReverseTether(iface);
                } else if (state == BluetoothPan.STATE_DISCONNECTED &&
                        (prevState == BluetoothPan.STATE_CONNECTED ||
                         prevState == BluetoothPan.STATE_DISCONNECTING)) {
                    BluetoothTetheringDataTracker.getInstance().stopReverseTether(panDevice.mIface);
                }
            }

            if (panDevice == null) {
                panDevice = new BluetoothPanDevice(state, ifaceAddr, iface, role);
                mPanDevices.put(device, panDevice);
            } else {
                panDevice.mState = state;
                panDevice.mIfaceAddr = ifaceAddr;
                panDevice.mLocalRole = role;
                panDevice.mIface = iface;
            }

            Intent intent = new Intent(BluetoothPan.ACTION_STATE_CHANGED);
            intent.putExtra(BluetoothDevice.EXTRA_DEVICE, device);
            intent.putExtra(BluetoothPan.EXTRA_PREVIOUS_STATE, prevState);
            intent.putExtra(BluetoothPan.EXTRA_STATE, state);
            intent.putExtra(BluetoothPan.EXTRA_LOCAL_ROLE, role);
            mContext.sendBroadcast(intent, BLUETOOTH_PERM);

            Log.e(TAG, "Pan Device state : device: " + device + " State:" + prevState + "->" + state);
        }
    }
/*    
    private String createNewTetheringAddressLocked() {
        if (getConnectedPanDevices().length == mMaxPanDevices) {
            Log.e (TAG, "Max PAN device connections reached");
            return null;
        }
        String address = BLUETOOTH_IFACE_ADDR_START;
        while (true) {
            if (mBluetoothIfaceAddresses.contains(address)) {
                String[] addr = address.split("\\.");
                Integer newIp = Integer.parseInt(addr[2]) + 1;
                address = address.replace(addr[2], newIp.toString());
            } else {
                break;
            }
        }
        mBluetoothIfaceAddresses.add(address);
        return address;
    }
*/     
    // configured when we start tethering
    private String enableTethering(String iface) {
        Log.e(TAG, "updateTetherState:" + iface);
/*
        IBinder b = ServiceManager.getService(Context.NETWORKMANAGEMENT_SERVICE);
        INetworkManagementService service = INetworkManagementService.Stub.asInterface(b);
        ConnectivityManager cm =
            (ConnectivityManager)mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        String[] bluetoothRegexs = cm.getTetherableBluetoothRegexs();

        // bring toggle the interfaces
        String[] currentIfaces = new String[0];
        try {
            currentIfaces = service.listInterfaces();
        } catch (Exception e) {
            Log.e(TAG, "Error listing Interfaces :" + e);
            return null;
        }

        boolean found = false;
        for (String currIface: currentIfaces) {
            if (currIface.equals(iface)) {
                found = true;
                break;
            }
        }

        if (!found) return null;

        String address = createNewTetheringAddressLocked();
        if (address == null) return null;

        InterfaceConfiguration ifcg = null;
        try {
            ifcg = service.getInterfaceConfig(iface);
            if (ifcg != null) {
                InetAddress addr = null;
                if (ifcg.addr == null || (addr = ifcg.addr.getAddress()) == null ||
                        addr.equals(NetworkUtils.numericToInetAddress("0.0.0.0")) ||
                        addr.equals(NetworkUtils.numericToInetAddress("::0"))) {
                    addr = NetworkUtils.numericToInetAddress(address);
                }
                ifcg.interfaceFlags = ifcg.interfaceFlags.replace("down", "up");
                ifcg.addr = new LinkAddress(addr, BLUETOOTH_PREFIX_LENGTH);
                ifcg.interfaceFlags = ifcg.interfaceFlags.replace("running", "");
                ifcg.interfaceFlags = ifcg.interfaceFlags.replace("  "," ");
                service.setInterfaceConfig(iface, ifcg);
                if (cm.tether(iface) != ConnectivityManager.TETHER_ERROR_NO_ERROR) {
                    Log.e(TAG, "Error tethering "+iface);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error configuring interface " + iface + ", :" + e);
            return null;
        }
        return address;*/
        return null;
    }


    //*****************************************
    @Override
    protected void finalize() throws Throwable {
        try {
            cleanupNative();
        } finally {
            super.finalize();
        }
    }

    @Override
    protected synchronized void dump(FileDescriptor fd, PrintWriter pw, String[] args) {
    }

    private static void log(String msg) {
        Log.d(TAG, msg);
    }

    private native boolean initNative();
    private native void cleanupNative();
    private native boolean setBluetoothTetheringNative(boolean value, String src_role, String bridge, String path);
    private native boolean connectPanDeviceNative(String path, String dstRole);
    private native boolean disconnectPanDeviceNative(String path);
    private native boolean disconnectPanServerDeviceNative(String path, String address, String iface);

    native String getAdapterPathNative();
}
