/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package android.bluetooth;

import android.annotation.SdkConstant;
import android.annotation.SdkConstant.SdkConstantType;
import android.server.BluetoothPanService;
import android.content.Context;
import android.os.ServiceManager;
import android.os.RemoteException;
import android.os.IBinder;
import android.util.Log;

import java.util.Arrays;
import java.util.Collections;
import java.util.Set;
import java.util.HashSet;

/**
 * Public API for controlling the Bluetooth PAN Profile Service.
 *
 * BluetoothPan is a proxy object for controlling the Bluetooth PAN
 * Service via IPC.
 *
 * Creating a BluetoothPan object will initiate a binding with the
 * BluetoothPanService service. Users of this object should call close() when they
 * are finished, so that this proxy object can unbind from the service.
 *
 * Currently the BluetoothPan service runs in the system server and this
 * proxy object will be immediately bound to the service on construction.
 *
 * Currently this class provides methods to connect to PAN s.
 *
 * @hide
 */
public final class BluetoothPan {
    private static final String TAG = "BluetoothPan";
    private static final boolean DBG = true;


    /** int extra for ACTION_STATE_CHANGED */
    public static final String EXTRA_STATE =
        "android.bluetooth.pan.extra.STATE";
    /** int extra for ACTION_STATE_CHANGED */
    public static final String EXTRA_PREVIOUS_STATE =
        "android.bluetooth.pan.extra.PREVIOUS_STATE";
    /** int extra for ACTION_STATE_CHANGED */
    public static final String EXTRA_LOCAL_ROLE =
        "android.bluetooth.pan.extra.LOCAL_ROLE";

    public static final int LOCAL_NAP_ROLE = 1;
    public static final int LOCAL_PANU_ROLE = 2;

    public static final String NAP_ROLE = "nap";
    public static final String NAP_BRIDGE = "pan1";

    /** Indicates the state of an PAN  has changed.
     * This intent will always contain EXTRA_STATE,
     * EXTRA_PREVIOUS_STATE and BluetoothDevice.EXTRA_DEVICE
     * extras.
     */
    @SdkConstant(SdkConstantType.BROADCAST_INTENT_ACTION)
    public static final String ACTION_STATE_CHANGED =
        "android.bluetooth.pan.action.STATE_CHANGED";

    public static final int STATE_DISCONNECTED = 0;
    public static final int STATE_CONNECTING   = 1;
    public static final int STATE_CONNECTED    = 2;
    public static final int STATE_DISCONNECTING = 3;

    public static final int PRIORITY_AUTO_CONNECT = 1000;
    public static final int PRIORITY_ON = 100;
    public static final int PRIORITY_OFF = 0;
    public static final int PRIORITY_UNDEFINED = -1;

    public static final int PAN_DISCONNECT_FAILED_NOT_CONNECTED = 1000;
    public static final int PAN_CONNECT_FAILED_ALREADY_CONNECTED = 1001;
    public static final int PAN_CONNECT_FAILED_ATTEMPT_FAILED = 1002;
    public static final int PAN_OPERATION_GENERIC_FAILURE = 1003;
    public static final int PAN_OPERATION_SUCCESS = 1004;

    private final IBluetoothPan mService;

    /**
     * Create a BluetoothPan proxy object for interacting with the local
     * Bluetooth PAN service.
     * @param c Context
     */
    public BluetoothPan(Context c) {
        if (DBG) Log.e(TAG, "BluetoothPan()");
        IBinder b = ServiceManager.getService(BluetoothPanService.BLUETOOTH_PAN_SERVICE);
        if (b != null) {
            mService = IBluetoothPan.Stub.asInterface(b);
        } else {
            Log.e(TAG, "Bluetooth PAN service not available!");

            mService = null;
        }
    }

    public Set<BluetoothDevice> getConnectedDevices() {
        if (DBG) Log.e(TAG,"getConnectedDevice()");
        try {
            return Collections.unmodifiableSet(new HashSet<BluetoothDevice>(Arrays.asList(mService.getConnectedPanDevices())));
        } catch (RemoteException e) {
            Log.e(TAG, "", e);
            return null;
        }
    }

    public boolean connect(BluetoothDevice device) {
        if (DBG) Log.e(TAG,"connect(" + device + ")");
        try {
            return mService.connectPanDevice(device);
        } catch (RemoteException e) {
            Log.e(TAG, "", e);
            return false;
        }
    }

    public boolean disconnect(BluetoothDevice device) {
        if (DBG) Log.e(TAG,"disconnect(" + device + ")");
        try {
            return mService.disconnectPanDevice(device);
        } catch (RemoteException e) {
            Log.e(TAG, "", e);
            return false;
        }
    }


    public int getConnectionState(BluetoothDevice device) {
        if (DBG) Log.e(TAG,"getConnectionState(" + device + ")");
        try {
            return mService.getPanDeviceConnectionState(device);
        } catch (RemoteException e) {
            Log.e(TAG, "", e);
            return -1;
        }
    }

    public void setBluetoothTethering(boolean value) {
        if (DBG) Log.e(TAG,"setBluetoothTethering(" + value + ")");
        try {
            mService.setBluetoothTethering(value);
        } catch (RemoteException e) {
            Log.e(TAG, "", e);
        }
    }

    public boolean isTetheringOn() {
        if (DBG) Log.e(TAG,"isTetheringOn");
        try {
            return mService.isTetheringOn();
        } catch (RemoteException e) {
            Log.e(TAG, "", e);
            return false;
        }
    }

    private static void log(String msg) {
        Log.e(TAG, msg);
    }
}
