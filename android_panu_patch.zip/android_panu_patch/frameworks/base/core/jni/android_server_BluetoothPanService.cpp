/*
** Copyright 2008, The Android Open Source Project
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/

#define LOG_TAG "BluetoothPanService.cpp"

#include "android_bluetooth_common.h"
#include "android_runtime/AndroidRuntime.h"
#include "JNIHelp.h"
#include "jni.h"
#include "utils/Log.h"
#include "utils/misc.h"

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#ifdef HAVE_BLUETOOTH
#include <dbus/dbus.h>
#endif

#define DBUS_NETWORK_IFACE BLUEZ_DBUS_BASE_IFC ".Network"
#define DBUS_NETWORKSERVER_IFACE BLUEZ_DBUS_BASE_IFC ".NetworkServer"

namespace android {

#ifdef HAVE_BLUETOOTH
static jmethodID method_onNetworkDeviceDisconnected;
static jmethodID method_onNetworkDeviceConnected;
static jmethodID method_onPanDevicePropertyChanged;
static jmethodID method_onPanDeviceConnectionResult;
 


typedef event_loop_native_data_t native_data_t;

static native_data_t *nat = NULL;  // global native data
static void onPanDeviceConnectionResult(DBusMessage *msg, void *user, void *nat);

#endif

/* Returns true on success (even if adapter is present but disabled).
 * Return false if dbus is down, or another serious error (out of memory)
*/
static bool initNative(JNIEnv* env, jobject object) {
    LOGV(__FUNCTION__);
#ifdef HAVE_BLUETOOTH
    nat = (native_data_t *)calloc(1, sizeof(native_data_t));
    if (NULL == nat) {
        LOGE("%s: out of memory!", __FUNCTION__);
        return false;
    }
    env->GetJavaVM( &(nat->vm) );
    nat->envVer = env->GetVersion();
    nat->me = env->NewGlobalRef(object);

    DBusError err;
    dbus_error_init(&err);
    dbus_threads_init_default();
    nat->conn = dbus_bus_get(DBUS_BUS_SYSTEM, &err);
    if (dbus_error_is_set(&err)) {
        LOGE("Could not get onto the system bus: %s", err.message);
        dbus_error_free(&err);
        return false;
    }
    dbus_connection_set_exit_on_disconnect(nat->conn, FALSE);
#endif  /*HAVE_BLUETOOTH*/
    return true;
}

static void cleanupNative(JNIEnv* env, jobject object) {
#ifdef HAVE_BLUETOOTH
    LOGV(__FUNCTION__);
    if (nat) {
        dbus_connection_close(nat->conn);
        env->DeleteGlobalRef(nat->me);
        free(nat);
        nat = NULL;
    }
#endif
}

static jboolean setBluetoothTetheringNative(JNIEnv *env, jobject object, jboolean value,
                                            jstring src_role, jstring bridge, jstring path) {
    LOGV("%s", __FUNCTION__);
#ifdef HAVE_BLUETOOTH
    if (nat) {
        DBusMessage *reply;
        const char *c_role = env->GetStringUTFChars(src_role, NULL);
        const char *c_bridge = env->GetStringUTFChars(bridge, NULL);
        const char *c_path = env->GetStringUTFChars(path, NULL);


        LOGE(" in %s: value:%d, role:%s, bridge:%s, path:%s", __func__, value, c_role, c_bridge, c_path);
        if (value) {
            LOGE("setBluetoothTetheringNative true");
            reply = dbus_func_args(env, nat->conn,
                                  c_path,//get_adapter_path(env, object),
                                  DBUS_NETWORKSERVER_IFACE,
                                  "Register",
                                  DBUS_TYPE_STRING, &c_role,
                                  DBUS_TYPE_STRING, &c_bridge,
                                  DBUS_TYPE_INVALID);
        } else {
            LOGE("setBluetoothTetheringNative false");
            reply = dbus_func_args(env, nat->conn,
                                  c_path,//get_adapter_path(env, object),
                                  DBUS_NETWORKSERVER_IFACE,
                                  "Unregister",
                                  DBUS_TYPE_STRING, &c_role,
                                  DBUS_TYPE_INVALID);
        }
        env->ReleaseStringUTFChars(src_role, c_role);
        env->ReleaseStringUTFChars(bridge, c_bridge);
        env->ReleaseStringUTFChars(path, c_path);
        return reply ? JNI_TRUE : JNI_FALSE;
    }
#endif
    return JNI_FALSE;
}

extern event_loop_native_data_t *get_EventLoop_native_data(JNIEnv *,
                                                           jobject);


static jboolean connectPanDeviceNative(JNIEnv *env, jobject object, jstring path, 
        jstring dstRole) {
    LOGV("%s", __FUNCTION__);
#ifdef HAVE_BLUETOOTH

    if (nat) {
        const char *c_path = env->GetStringUTFChars(path, NULL);
        const char *dst = env->GetStringUTFChars(dstRole, NULL);

        int len = env->GetStringLength(path) + 1;
        char *context_path = (char *)calloc(len, sizeof(char));
        strlcpy(context_path, c_path, len);  // for callback

        LOGE("in %s: c_path:%s, dest:%s", __func__, c_path, dst);

        bool ret = dbus_func_args_async(env, nat->conn, -1, onPanDeviceConnectionResult,
                context_path, nat, c_path,
                DBUS_NETWORK_IFACE, "Connect",
                DBUS_TYPE_STRING, &dst,
                DBUS_TYPE_INVALID);

        env->ReleaseStringUTFChars(path, c_path);
        env->ReleaseStringUTFChars(dstRole, dst);
        LOGE("end of connectNative");

        return ret ? JNI_TRUE : JNI_FALSE;
    }
#endif
    return JNI_FALSE;
}

static jboolean disconnectPanDeviceNative(JNIEnv *env, jobject object,
                                     jstring path) {
    LOGV("%s", __FUNCTION__);
#ifdef HAVE_BLUETOOTH
    LOGE("disconnectPanDeviceNative");

    if (nat ) {
        const char *c_path = env->GetStringUTFChars(path, NULL);

        int len = env->GetStringLength(path) + 1;
        char *context_path = (char *)calloc(len, sizeof(char));
        strlcpy(context_path, c_path, len);  // for callback

        LOGE("in %s: role:%s", __func__, c_path);
        bool ret = dbus_func_args_async(env, nat->conn, -1,onPanDeviceConnectionResult,
                                        context_path, nat, c_path,
                                        DBUS_NETWORK_IFACE, "Disconnect",
                                        DBUS_TYPE_INVALID);

        env->ReleaseStringUTFChars(path, c_path);
        return ret ? JNI_TRUE : JNI_FALSE;
    }
#endif
    return JNI_FALSE;
}

static jboolean disconnectPanServerDeviceNative(JNIEnv *env, jobject object,
                                                jstring path, jstring address,
                                                jstring iface) {
    LOGV("%s", __FUNCTION__);
#ifdef HAVE_BLUETOOTH
    LOGE("disconnectPanServerDeviceNative");

    if (nat ) {
        const char *c_address = env->GetStringUTFChars(address, NULL);
        const char *c_path = env->GetStringUTFChars(path, NULL);
        const char *c_iface = env->GetStringUTFChars(iface, NULL);

        int len = env->GetStringLength(path) + 1;
        char *context_path = (char *)calloc(len, sizeof(char));
        strlcpy(context_path, c_path, len);  // for callback

        LOGE(" in %s: path:%s, addrss:%s, iface", __func__, c_path, c_address, c_iface);
        bool ret = dbus_func_args_async(env, nat->conn, -1,
                                        onPanDeviceConnectionResult,
                                        context_path, nat,
                                        c_path,//get_adapter_path(env, object),
                                        DBUS_NETWORKSERVER_IFACE,
                                        "DisconnectDevice",
                                        DBUS_TYPE_STRING, &c_address,
                                        DBUS_TYPE_STRING, &c_iface,
                                        DBUS_TYPE_INVALID);

        env->ReleaseStringUTFChars(address, c_address);
        env->ReleaseStringUTFChars(iface, c_iface);
        env->ReleaseStringUTFChars(path, c_path);
        return ret ? JNI_TRUE : JNI_FALSE;
    }
#endif
    return JNI_FALSE;
}


#ifdef HAVE_BLUETOOTH
DBusHandlerResult pan_event_filter(DBusMessage *msg, JNIEnv *env) {
    DBusError err;

    LOGE("pan_event_filter\n ");
    if (!nat) {
        LOGV("... skipping %s\n", __FUNCTION__);
        LOGV("... ignored\n");
        return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
    }

    dbus_error_init(&err);

    if (dbus_message_get_type(msg) != DBUS_MESSAGE_TYPE_SIGNAL) {
        return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
    }

    DBusHandlerResult result = DBUS_HANDLER_RESULT_NOT_YET_HANDLED;

    if (dbus_message_is_signal(msg,
                                     "org.bluez.Network",
                                     "PropertyChanged")) {

       jobjectArray str_array =
                   parse_pan_property_change(env, msg);
       LOGE("org.bluez.Network PropertyChanged");
       if (str_array != NULL) {
           const char *c_path = dbus_message_get_path(msg);
           env->CallVoidMethod(nat->me,
                   method_onPanDevicePropertyChanged,
                   env->NewStringUTF(c_path),
                   str_array);
           result = DBUS_HANDLER_RESULT_HANDLED;
           return result;
       } else {
           LOG_AND_FREE_DBUS_ERROR_WITH_MSG(&err, msg);
       }
    } else if (dbus_message_is_signal(msg,
                                     "org.bluez.NetworkServer",
                                     "DeviceDisconnected")) {
       char *c_address;
       LOGE("org.bluez.NetworkServer DeviceDisconnected");
       if (dbus_message_get_args(msg, &err,
                                  DBUS_TYPE_STRING, &c_address,
                                  DBUS_TYPE_INVALID)) {
           env->CallVoidMethod(nat->me,
                               method_onNetworkDeviceDisconnected,
                               env->NewStringUTF(c_address));
           result = DBUS_HANDLER_RESULT_HANDLED;
           return result;
       } else {
           LOG_AND_FREE_DBUS_ERROR_WITH_MSG(&err, msg);
       }
    } else if (dbus_message_is_signal(msg,
                                     "org.bluez.NetworkServer",
                                     "DeviceConnected")) {
       char *c_address;
       char *c_iface;
       uint16_t uuid;

       LOGE("org.bluez.NetworkServer DeviceConnected");
       if (dbus_message_get_args(msg, &err,
                                  DBUS_TYPE_STRING, &c_address,
                                  DBUS_TYPE_STRING, &c_iface,
                                  DBUS_TYPE_UINT16, &uuid,
                                  DBUS_TYPE_INVALID)) {
           env->CallVoidMethod(nat->me,
                               method_onNetworkDeviceConnected,
                               env->NewStringUTF(c_address),
                               env->NewStringUTF(c_iface),
                               uuid);
           result = DBUS_HANDLER_RESULT_HANDLED;
           return result;
       } else {
           LOG_AND_FREE_DBUS_ERROR_WITH_MSG(&err, msg);
       }
    }else{
        LOGV("... ignored");
    }
    if (env->ExceptionCheck()) {
        LOGE("VM Exception occurred while handling %s.%s (%s) in %s,"
             " leaving for VM",
             dbus_message_get_interface(msg), dbus_message_get_member(msg),
             dbus_message_get_path(msg), __FUNCTION__);
    }

    return result;
}

void onPanDeviceConnectionResult(DBusMessage *msg, void *user, void *n) {
    LOGE("%s", __FUNCTION__);

    native_data_t *nat = (native_data_t *)n;
    const char *path = (const char *)user;
    DBusError err;
    dbus_error_init(&err);
    JNIEnv *env;
    nat->vm->GetEnv((void**)&env, nat->envVer);

    jint result = PAN_OPERATION_SUCCESS;
    if (dbus_set_error_from_message(&err, msg)) {
        if (!strcmp(err.name, BLUEZ_ERROR_IFC ".ConnectionAttemptFailed")) {
            result = PAN_CONNECT_FAILED_ATTEMPT_FAILED;
        } else if (!strcmp(err.name, BLUEZ_ERROR_IFC ".Failed")) {
            // TODO():This is flaky, need to change Bluez to add new error codes
            if (!strcmp(err.message, "Device already connected")) {
                result = PAN_CONNECT_FAILED_ALREADY_CONNECTED;
            } else if (!strcmp(err.message, "Device not connected")) {
                result = PAN_DISCONNECT_FAILED_NOT_CONNECTED;
            } else {
                result = PAN_OPERATION_GENERIC_FAILURE;
            }
        } else {
            result = PAN_OPERATION_GENERIC_FAILURE;
        }
        LOG_AND_FREE_DBUS_ERROR(&err);
    }

    LOGE(" Pan Device Path = %s, result = %d", path, result);
    jstring jPath = env->NewStringUTF(path);
    env->CallVoidMethod(nat->me,
                        method_onPanDeviceConnectionResult,
                        jPath,
                        result);
    env->DeleteLocalRef(jPath);
    free(user);
}

#endif


static JNINativeMethod sMethods[] = {
    {"initNative", "()Z", (void *)initNative},
    {"cleanupNative", "()V", (void *)cleanupNative},

    {"setBluetoothTetheringNative", "(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z",
              (void *)setBluetoothTetheringNative},
    {"connectPanDeviceNative", "(Ljava/lang/String;Ljava/lang/String;)Z",
              (void *)connectPanDeviceNative},
    {"disconnectPanDeviceNative", "(Ljava/lang/String;)Z", (void *)disconnectPanDeviceNative},
    {"disconnectPanServerDeviceNative", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z",
              (void *)disconnectPanServerDeviceNative},

};

int register_android_server_BluetoothPanService(JNIEnv *env) {
    jclass clazz = env->FindClass("android/server/BluetoothPanService");
    if (clazz == NULL) {
        LOGE("Can't find android/server/BluetoothPanService");
        return -1;

    }

#ifdef HAVE_BLUETOOTH
    method_onNetworkDeviceConnected = env->GetMethodID(clazz, "onNetworkDeviceConnected",
            "(Ljava/lang/String;Ljava/lang/String;I)V");
    method_onNetworkDeviceDisconnected = env->GetMethodID(clazz, "onNetworkDeviceDisconnected",
            "(Ljava/lang/String;)V");
    method_onPanDevicePropertyChanged = env->GetMethodID(clazz, "onPanDevicePropertyChanged",
            "(Ljava/lang/String;[Ljava/lang/String;)V");
    method_onPanDeviceConnectionResult = env->GetMethodID(clazz, "onPanDeviceConnectionResult",
            "(Ljava/lang/String;I)V");
#endif

    return AndroidRuntime::registerNativeMethods(env,
            "android/server/BluetoothPanService", sMethods, NELEM(sMethods));
}

} /* namespace android */
